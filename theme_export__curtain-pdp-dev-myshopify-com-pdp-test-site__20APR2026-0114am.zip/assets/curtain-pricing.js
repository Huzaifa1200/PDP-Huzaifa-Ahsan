class CurtainPricing {
  constructor(sectionId) {
    this.sectionId = sectionId;
    console.log('CurtainPricing initializing for section:', sectionId);
    this.init();
  }

  init() {
    // Find container first
    const sectionContainer = document.querySelector(`.curtain-variant-picker[data-section-id="${this.sectionId}"]`) ||
                            document.querySelector('.curtain-variant-picker');
    
    if (!sectionContainer) {
      console.error('Curtain container not found for section:', this.sectionId);
      return;
    }

    // Find all required elements within container
    this.widthSelect = sectionContainer.querySelector('.curtain-width-select');
    this.dropSelect = sectionContainer.querySelector('.curtain-drop-select');
    this.metafieldsScript = sectionContainer.querySelector('[id^="curtain-metafields"]');
    this.panelsInput = sectionContainer.querySelector('.curtain-fabric-panels');
    this.variantInput = sectionContainer.querySelector('.product-variant-id');
    this.addToCartBtn = document.querySelector(`#CurtainSubmitButton-${this.sectionId}`) || 
                       document.querySelector('.curtain-add-to-cart');
    this.priceDisplay = this.addToCartBtn?.querySelector('.curtain-price-display');
    this.debugElements = sectionContainer.querySelectorAll('.curtain-debug span');

    console.log('Found elements:', {
      widthSelect: !!this.widthSelect,
      dropSelect: !!this.dropSelect,
      metafieldsScript: !!this.metafieldsScript,
      addToCartBtn: !!this.addToCartBtn
    });

    // Load metafields
    if (!this.metafieldsScript) {
      console.error(' NO METAFIELDS SCRIPT FOUND!');
      this.showError('Missing metafield data');
      return;
    }

    try {
      this.metafields = JSON.parse(this.metafieldsScript.textContent);
      console.log('Metafields loaded:', this.metafields);
    } catch (e) {
      console.error('Metafields parse error:', e);
      this.showError('Invalid metafield data');
      return;
    }

    // Validate required data
    if (!this.metafields.width_mapping || !this.metafields.pricing_table) {
      console.error('Missing required metafields');
      this.showError('Incomplete pricing data');
      return;
    }

    // Set default values and event listeners
    if (this.widthSelect) {
      this.widthSelect.value = Object.keys(this.metafields.width_mapping)[0] || '';
      this.widthSelect.addEventListener('change', () => this.updateFromSelects());
    }

    if (this.dropSelect) {
      this.dropSelect.addEventListener('change', () => this.updateFromSelects());
    }

    // Initial calculation after short delay
    setTimeout(() => {
      this.updateFromSelects();
    }, 200);

    console.log('CurtainPricing fully initialized');
  }

  updateFromSelects() {
    if (!this.widthSelect || !this.dropSelect) return;

    this.currentWidth = parseInt(this.widthSelect.value);
    this.currentDrop = parseInt(this.dropSelect.value);

    console.log('Selection values:', {
      width: this.currentWidth,
      drop: this.currentDrop,
      widthRaw: this.widthSelect.value,
      dropRaw: this.dropSelect.value
    });

    // Calculate fabric panels
    this.currentPanels = this.getFabricPanels(this.currentWidth);
    if (this.panelsInput) {
      this.panelsInput.value = this.currentPanels || '';
    }

    // Calculate price
    const price = this.calculatePrice();
    console.log('Final calculation:', { 
      panels: this.currentPanels, 
      price: price 
    });

    this.updateUI(price);
    this.updateDebug();
  }

  getFabricPanels(width) {
    if (!width || isNaN(width)) return null;
    
    const panels = this.metafields.width_mapping[width.toString()];
    console.log('Fabric panels lookup:', width, '→', panels);
    return panels;
  }

  calculatePrice() {
    if (!this.currentPanels || !this.currentDrop || isNaN(this.currentPanels) || isNaN(this.currentDrop)) {
      console.log('Missing panels or drop for price calc');
      return 0;
    }

    const panelsKey = this.currentPanels.toString();
    const dropKey = this.currentDrop.toString();

    console.log('Price lookup keys:', { panelsKey, dropKey });
    console.log('Available pricing table:', this.metafields.pricing_table);

    const price = this.metafields.pricing_table[panelsKey]?.[dropKey];
    
    if (!price) {
      console.warn('No price found for combination:', panelsKey, dropKey);
    }

    console.log('Price result:', price);
    return price || 0;
  }

  updateUI(price) {
    if (!this.priceDisplay || !this.addToCartBtn) return;

    // Update price display
    const formattedPrice = price ? 
      `$${price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : 
      '$0.00';

    this.priceDisplay.textContent = formattedPrice;

    // Update button state
    if (price > 0 && this.currentPanels && this.currentDrop) {
      this.addToCartBtn.disabled = false;
      this.addToCartBtn.classList.remove('disabled');
      this.variantInput.disabled = false;
    } else {
      this.addToCartBtn.disabled = true;
      this.addToCartBtn.classList.add('disabled');
      this.variantInput.disabled = true;
    }
  }

  updateDebug() {
    if (this.debugElements.length >= 4) {
      this.debugElements[0].textContent = this.currentWidth || '-';
      this.debugElements[1].textContent = this.currentPanels || '-';
      this.debugElements[2].textContent = this.currentDrop || '-';
      this.debugElements[3].textContent = this.calculatePrice() || '-';
    }
  }

  showError(message) {
    if (this.addToCartBtn) {
      this.addToCartBtn.innerHTML = `<span style="color: red;">${message}</span>`;
    }
  }
}


function initializeCurtainPricings() {
  console.log('Initializing curtain pricings...');
  
  document.querySelectorAll('.curtain-variant-picker:not(.curtain-initialized)').forEach((picker) => {
    const sectionId = picker.dataset.sectionId || 'default';
    
    if (!picker.classList.contains('curtain-initialized')) {
      new CurtainPricing(sectionId);
      picker.classList.add('curtain-initialized');
    }
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeCurtainPricings);
} else {
  initializeCurtainPricings();
}

document.addEventListener('shopify:section:load', initializeCurtainPricings);
document.addEventListener('shopify:block:select', initializeCurtainPricings);

if (window.Shopify?.designMode) {
  document.addEventListener('shopify:section:load', initializeCurtainPricings);
}

console.log('🚀 Curtain Pricing script loaded');